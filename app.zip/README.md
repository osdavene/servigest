# ServiGest - SaaS Multi-inquilino para Talleres de Servicio Técnico

**ServiGest** es una plataforma web SaaS (*Software as a Service*) de arquitectura multi-inquilino (*Multi-Tenant*) desarrollada en **Laravel 11** y **PHP 8.2+**, diseñada para talleres y centros de servicio técnico de computación, electrónica, refrigeración, electrodomésticos, motocicletas y maquinaria.

---

## 🚀 Características Principales

### 🏢 1. Arquitectura Multi-Inquilino (Single Database)
- **Aislamiento Lógico**: Cada taller cliente cuenta con un identificador único `taller_id`.
- **Global Scopes Automáticos**: Mediante el trait `TieneTaller` y el scope `TallerScope`, todas las consultas `SELECT`, `UPDATE` y `DELETE` filtran de forma transparente los registros por el taller del usuario autenticado.
- **Auto-asignación en `creating`**: Al insertar clientes, categorías, equipos u órdenes, el `taller_id` se inyecta automáticamente desde la sesión del usuario.

### 👥 2. Gestión de Clientes y Comunicación Rápida
- CRUD completo con datos de identificación, teléfono, dirección y barrio.
- **Acceso Directo a WhatsApp**: Botón dinámico que abre WhatsApp Web o Móvil (`wa.me/57...`) con mensaje precargado.
- **Georreferenciación Inmediata**: Botones de un clic para abrir la dirección en **Google Maps** o navegar paso a paso con **Waze**.

### 🏷️ 3. Categorías Dinámicas y Personalizables por Taller
- Cada taller define sus propias categorías de equipos (ej. *Laptops*, *Neveras No-Frost*, *Televisores OLED*, *Motos 4T*).
- Configuración de periodos de **Mantenimiento Preventivo** recomendados (en días).

### 💻 4. Gestión de Equipos y Alertas Preventivas
- Registro con marca, modelo, número de serie y observaciones físicas (golpes, estado de recepción).
- **Semáforo de Mantenimiento Preventivo**: Cálculo en tiempo real de días restantes o alerta visual de vencimiento.

### 📋 5. Órdenes de Trabajo e Historial Técnico
- Modalidad del servicio: *Ingresado al taller* o *Servicio a domicilio*.
- Flujo de estados: *Pendiente*, *En Proceso*, *Finalizado*, *Entregado*, *Cancelado*.
- Registro de problema reportado, diagnóstico, procedimientos y repuestos.
- **Liquidación Automática**: Cálculo en vivo de Mano de Obra + Repuestos.

### ✍️ 6. Firma Digital Táctil (HTML5 Canvas)
- Módulo de firma digital en pantalla (compatible con dedos en pantallas táctiles de móviles/tablets y ratón en PC).
- Almacenamiento seguro de la firma en formato PNG para el comprobante de entrega.

### 📸 7. Evidencias Fotográficas
- Carga de múltiples fotografías clasificadas por etapa (*Antes / Recepción*, *Durante el proceso*, *Falla en placa / componente*, *Después / Reparado*).

### 📄 8. Exportación e Informe Técnico (PDF & WhatsApp)
- Generación automática de informe técnico en PDF con membrete del taller, datos del cliente, diagnóstico, fotos y firma.
- **Notificación por WhatsApp**: Generación instantánea de enlace `wa.me` con el mensaje oficial de finalización y el enlace público seguro de descarga del PDF.

---

## 👤 Cuentas y Roles Preconfigurados (Seeder)

| Rol | Correo Electrónico | Contraseña | Alcance |
|---|---|---|---|
| **Super Administrador** | `superadmin@servigest.com` | `password123` | Control total del SaaS y suscripciones de talleres |
| **Administrador de Taller** | `admin@electrotech.com` | `password123` | Dueño del taller (ElectroTech Soluciones) |
| **Técnico** | `diego@electrotech.com` | `password123` | Técnico operativo (Órdenes, firmas y fotos) |

---

## 🛠️ Puesta en Marcha

1. **Instalar dependencias de PHP**:
   ```bash
   composer install
   ```

2. **Generar la clave de la aplicación y enlace simbólico de almacenamiento**:
   ```bash
   php artisan key:generate
   php artisan storage:link
   ```

3. **Ejecutar migraciones y datos de prueba**:
   ```bash
   php artisan migrate --seed
   ```

4. **Iniciar el servidor de desarrollo**:
   ```bash
   php artisan serve
   ```

Accede a la aplicación en `http://localhost:8000`.
