<?php

namespace Database\Seeders;

use App\Models\Categoria;
use App\Models\Cliente;
use App\Models\Equipo;
use App\Models\OrdenTrabajo;
use App\Models\PlanLicencia;
use App\Models\Taller;
use App\Models\Usuario;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // 0. Planes de Licencia SaaS creados por el SuperAdmin
        $this->call(PlanLicenciaSeeder::class);

        $planMensual = PlanLicencia::where('dias_duracion', 30)->where('es_prueba', false)->first();
        $planDemo = PlanLicencia::where('es_prueba', true)->first();

        // 1. Super Administrador del Sistema SaaS ServiGest
        Usuario::create([
            'taller_id' => null,
            'nombre' => 'Super',
            'apellido' => 'Administrador',
            'email' => 'superadmin@servigest.com',
            'telefono' => '573009998877',
            'password' => Hash::make('password123'),
            'rol' => 'super_administrador',
            'esta_activo' => true,
        ]);

        // 2. Taller Principal: ElectroTech Soluciones Integrales
        $tallerElectroTech = Taller::create([
            'plan_licencia_id' => $planMensual?->id,
            'nombre_comercial' => 'ElectroTech Soluciones Integrales',
            'identificacion_fiscal' => 'NIT 900.123.456-7',
            'telefono' => '573105554433',
            'email' => 'contacto@electrotech.com',
            'direccion' => 'Carrera 15 # 85-30',
            'ciudad' => 'Bogotá',
            'texto_garantia' => 'Garantía legal de 90 días calendario sobre mano de obra y repuestos sustituidos. No cubre daños ocasionados por descargas eléctricas, humedad o manipulación por terceros no autorizados.',
            'prefijo_orden' => 'OT',
            'estado_suscripcion' => 'activo',
            'fecha_vencimiento_suscripcion' => now()->addYear(),
        ]);

        // Usuarios del Taller 1
        $adminElectroTech = Usuario::create([
            'taller_id' => $tallerElectroTech->id,
            'nombre' => 'Carlos',
            'apellido' => 'Mendoza',
            'email' => 'admin@electrotech.com',
            'telefono' => '573105554433',
            'password' => Hash::make('password123'),
            'rol' => 'administrador',
            'esta_activo' => true,
        ]);

        $tecnicoElectroTech = Usuario::create([
            'taller_id' => $tallerElectroTech->id,
            'nombre' => 'Diego',
            'apellido' => 'Ramírez',
            'email' => 'diego@electrotech.com',
            'telefono' => '573117778899',
            'password' => Hash::make('password123'),
            'rol' => 'tecnico',
            'esta_activo' => true,
        ]);

        // Categorías personalizadas del Taller 1
        $catPortatiles = Categoria::create([
            'taller_id' => $tallerElectroTech->id,
            'nombre' => 'Laptops & Computadores',
            'descripcion' => 'Mantenimiento y reparación de hardware y software en portátiles y PCs.',
            'requiere_mantenimiento_preventivo' => true,
            'intervalo_mantenimiento_dias' => 180, // 6 meses
        ]);

        $catNeveras = Categoria::create([
            'taller_id' => $tallerElectroTech->id,
            'nombre' => 'Neveras & Refrigeración',
            'descripcion' => 'Neveras no-frost, congeladores y enfriadores industriales.',
            'requiere_mantenimiento_preventivo' => true,
            'intervalo_mantenimiento_dias' => 365, // 1 año
        ]);

        $catTV = Categoria::create([
            'taller_id' => $tallerElectroTech->id,
            'nombre' => 'Smart TVs & Pantallas',
            'descripcion' => 'Reparación de tarjetas principales, fuentes de poder y backlights.',
            'requiere_mantenimiento_preventivo' => false,
        ]);

        // Clientes del Taller 1
        $cliente1 = Cliente::create([
            'taller_id' => $tallerElectroTech->id,
            'nombre_completo' => 'María Camila Gómez',
            'identificacion' => 'CC 1020304050',
            'telefono' => '573001234567',
            'email' => 'camila.gomez@gmail.com',
            'direccion' => 'Calle 127 # 45-20',
            'barrio' => 'Unicentro',
            'ciudad' => 'Bogotá',
            'latitud' => 4.707264,
            'longitud' => -74.041695,
            'notas_adicionales' => 'Cliente preferencial, llamar antes de visitar.',
        ]);

        $cliente2 = Cliente::create([
            'taller_id' => $tallerElectroTech->id,
            'nombre_completo' => 'Andrés Felipe Castro',
            'identificacion' => 'CC 79854120',
            'telefono' => '573159876543',
            'email' => 'andres.castro@empresa.com',
            'direccion' => 'Avenida Boyacá # 68-15',
            'barrio' => 'Normandía',
            'ciudad' => 'Bogotá',
            'latitud' => 4.673820,
            'longitud' => -74.108420,
            'notas_adicionales' => 'Conjunto cerrado, ingresar por portería 2.',
        ]);

        // Equipos del Taller 1
        $equipo1 = Equipo::create([
            'taller_id' => $tallerElectroTech->id,
            'cliente_id' => $cliente1->id,
            'categoria_id' => $catPortatiles->id,
            'marca' => 'Dell',
            'modelo' => 'Inspiron 15 3520',
            'numero_serie' => 'DELL-98745632-X',
            'observaciones_fisicas' => 'Tapa con rayones leves, cargador original incluido.',
            'fecha_ultimo_servicio' => now()->subMonths(7)->toDateString(),
            'fecha_proximo_mantenimiento' => now()->subDays(10)->toDateString(), // Alerta vencida
        ]);

        $equipo2 = Equipo::create([
            'taller_id' => $tallerElectroTech->id,
            'cliente_id' => $cliente2->id,
            'categoria_id' => $catNeveras->id,
            'marca' => 'Whirlpool',
            'modelo' => 'No-Frost 420L Inverter',
            'numero_serie' => 'WP-NF-2023-99',
            'observaciones_fisicas' => 'Puerta derecha con pequeño abollón.',
            'fecha_ultimo_servicio' => now()->subMonths(11)->toDateString(),
            'fecha_proximo_mantenimiento' => now()->addDays(5)->toDateString(), // Próximo a vencer
        ]);

        // Órdenes de Trabajo del Taller 1
        OrdenTrabajo::create([
            'taller_id' => $tallerElectroTech->id,
            'codigo_orden' => 'OT-00001',
            'cliente_id' => $cliente1->id,
            'equipo_id' => $equipo1->id,
            'tecnico_asignado_id' => $tecnicoElectroTech->id,
            'tipo_ubicacion' => 'ingresado_al_taller',
            'estado' => 'finalizado',
            'problema_reportado' => 'El computador recalienta excesivamente y se apaga a los 20 minutos de uso.',
            'diagnostico' => 'Ventilador obstruido por polvo denso y pasta térmica totalmente seca y cristalizada.',
            'procedimiento_realizado' => 'Mantenimiento preventivo general, limpieza por ultrasonido de disipador, lubricación de cooler y aplicación de pasta térmica de alto rendimiento Noctua NT-H1.',
            'repuestos_usados' => 'Pasta térmica Noctua NT-H1 (1.5g)',
            'costo_mano_obra' => 80000,
            'costo_repuestos' => 35000,
            'costo_total' => 115000,
            'nombre_firmante' => 'María Camila Gómez',
            'fecha_firma' => now()->subHours(2),
            'token_publico_pdf' => (string) Str::uuid(),
            'fecha_ingreso' => now()->subDays(2),
            'fecha_promesa' => now()->subDays(1),
            'fecha_finalizacion' => now()->subHours(2),
        ]);

        OrdenTrabajo::create([
            'taller_id' => $tallerElectroTech->id,
            'codigo_orden' => 'OT-00002',
            'cliente_id' => $cliente2->id,
            'equipo_id' => $equipo2->id,
            'tecnico_asignado_id' => $tecnicoElectroTech->id,
            'tipo_ubicacion' => 'servicio_en_domicilio',
            'estado' => 'en_proceso',
            'problema_reportado' => 'La nevera enfría abajo pero el congelador acumula escarcha y bloquea ductos.',
            'diagnostico' => 'Resistencia de descongelamiento abierta y sensor bimetálico averiado.',
            'procedimiento_realizado' => 'Diagnóstico en sitio, revisión de ciclo de descongelación forzada con multímetro.',
            'repuestos_usados' => 'Sensor bimetálico L55 y resistencia tubular 110V',
            'costo_mano_obra' => 120000,
            'costo_repuestos' => 90000,
            'costo_total' => 210000,
            'token_publico_pdf' => (string) Str::uuid(),
            'fecha_ingreso' => now()->subHours(5),
            'fecha_promesa' => now()->addDay(),
        ]);

        // 3. Taller 2 Demo (Para demostrar aislamiento multi-inquilino)
        $tallerMecatronica = Taller::create([
            'plan_licencia_id' => $planDemo?->id,
            'nombre_comercial' => 'Mecatrónica Gómez & Cía',
            'identificacion_fiscal' => 'NIT 890.987.654-3',
            'telefono' => '573014443322',
            'email' => 'soporte@mecanicagomez.com',
            'direccion' => 'Calle 33 # 65-10',
            'ciudad' => 'Medellín',
            'estado_suscripcion' => 'periodo_prueba',
            'fecha_vencimiento_suscripcion' => now()->addDays(15),
        ]);

        Usuario::create([
            'taller_id' => $tallerMecatronica->id,
            'nombre' => 'Roberto',
            'apellido' => 'Gómez',
            'email' => 'admin@mecanicagomez.com',
            'telefono' => '573014443322',
            'password' => Hash::make('password123'),
            'rol' => 'administrador',
            'esta_activo' => true,
        ]);
    }
}
