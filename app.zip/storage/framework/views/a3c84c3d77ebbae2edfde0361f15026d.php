<?php $__env->startSection('titulo', 'Gestión de Clientes'); ?>

<?php $__env->startSection('contenido'); ?>
<div>

    <div class="filter-bar">
        <form method="GET" action="<?php echo e(route('clientes.index')); ?>" id="formBuscarClientes" class="search-group" style="flex: 1; max-width: 540px;">
            <div class="search-input-wrapper" style="width: 100%;">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" 
                       id="inputBuscarClientes"
                       name="buscar" 
                       value="<?php echo e($busqueda ?? ''); ?>" 
                       oninput="autoBuscar(this.form)"
                       placeholder="🔍 Escribe nombre, Cédula / Documento, teléfono, barrio..." 
                       class="input-control"
                       autofocus>
            </div>
            <?php if(!empty($busqueda)): ?>
                <a href="<?php echo e(route('clientes.index')); ?>" class="btn btn-outline btn-icon" title="Limpiar búsqueda">
                    <i class="fa-solid fa-xmark"></i>
                </a>
            <?php endif; ?>
        </form>

        <a href="<?php echo e(route('clientes.create')); ?>" class="btn btn-primary">
            <i class="fa-solid fa-user-plus"></i>
            <span>Nuevo Cliente</span>
        </a>
    </div>

    <!-- Tabla de Clientes -->
    <div class="table-card">
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Cliente / Documento</th>
                        <th>WhatsApp & Teléfono</th>
                        <th>Ubicación (Maps / Waze)</th>
                        <th style="text-align: center;">Equipos</th>
                        <th style="text-align: center;">Órdenes</th>
                        <th style="text-align: right;">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(route('clientes.show', $cliente)); ?>" style="font-weight: 800; color: #0284c7; text-decoration: none; font-size: 14px; display: block;">
                                    <?php echo e($cliente->nombre_completo); ?>

                                </a>
                                <span style="font-size: 11px; color: #64748b; font-family: monospace; font-weight: 700;">
                                    <?php echo e($cliente->identificacion ? 'Doc: ' . $cliente->identificacion : 'Sin documento'); ?>

                                </span>
                            </td>
                            <td>
                                <div style="display: flex; align-items: center; gap: 8px;">
                                    <strong style="color: #334155;"><?php echo e($cliente->telefono); ?></strong>
                                    <!-- Botón WhatsApp Directo -->
                                    <a href="<?php echo e($cliente->enlace_whatsapp); ?>" target="_blank" class="btn btn-emerald btn-icon" title="Abrir chat en WhatsApp" style="width: 28px; height: 28px; font-size: 13px;">
                                        <i class="fa-brands fa-whatsapp"></i>
                                    </a>
                                </div>
                                <?php if($cliente->email): ?>
                                    <span style="font-size: 11px; color: #94a3b8; display: block; margin-top: 2px;"><?php echo e($cliente->email); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div style="font-size: 12.5px; color: #334155;">
                                    <?php echo e($cliente->direccion); ?>

                                    <?php if($cliente->barrio): ?>
                                        <span style="color: #64748b; font-size: 11.5px;">- <?php echo e($cliente->barrio); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div style="display: flex; gap: 6px; margin-top: 4px;">
                                    <a href="<?php echo e($cliente->enlace_google_maps); ?>" target="_blank" style="font-size: 11px; color: #0284c7; text-decoration: none; font-weight: 700;">
                                        <i class="fa-solid fa-map-location-dot"></i> Maps
                                    </a>
                                    <span style="color: #cbd5e1;">•</span>
                                    <a href="<?php echo e($cliente->enlace_waze); ?>" target="_blank" style="font-size: 11px; color: #0891b2; text-decoration: none; font-weight: 700;">
                                        <i class="fa-brands fa-waze"></i> Waze
                                    </a>
                                </div>
                            </td>
                            <td style="text-align: center;">
                                <span class="badge" style="background: #f5f3ff; color: #7c3aed; border-color: #ddd6fe; font-size: 11px;">
                                    <?php echo e($cliente->equipos_count); ?> <?php echo e(Str::plural('Equipo', $cliente->equipos_count)); ?>

                                </span>
                            </td>
                            <td style="text-align: center;">
                                <span class="badge" style="background: #e0f2fe; color: #0369a1; border-color: #bae6fd; font-size: 11px;">
                                    <?php echo e($cliente->ordenes_trabajo_count); ?> <?php echo e(Str::plural('Orden', $cliente->ordenes_trabajo_count)); ?>

                                </span>
                            </td>
                            <td style="text-align: right;">
                                <div style="display: inline-flex; gap: 6px;">
                                    <a href="<?php echo e(route('ordenes.create', ['cliente_id' => $cliente->id])); ?>" class="btn btn-primary" style="padding: 6px 10px; font-size: 11px;" title="Nueva Orden">
                                        + Orden
                                    </a>
                                    <a href="<?php echo e(route('clientes.show', $cliente)); ?>" class="btn btn-outline btn-icon" title="Ver Perfil">
                                        <i class="fa-solid fa-eye" style="color: #0284c7;"></i>
                                    </a>
                                    <a href="<?php echo e(route('clientes.edit', $cliente)); ?>" class="btn btn-outline btn-icon" title="Editar">
                                        <i class="fa-solid fa-pen-to-square" style="color: #d97706;"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" style="text-align: center; padding: 40px; color: #94a3b8;">
                                <i class="fa-solid fa-user-slash" style="font-size: 32px; display: block; margin-bottom: 8px;"></i>
                                No se encontraron clientes que coincidan con "<?php echo e($busqueda); ?>".
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($clientes->hasPages()): ?>
            <div style="padding: 16px 20px; border-top: 1px solid var(--border);">
                <?php echo e($clientes->links()); ?>

            </div>
        <?php endif; ?>
    </div>

</div>

<script>
    var debounceTimer;
    function autoBuscar(form) {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(function() {
            form.submit();
        }, 400);
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Proyectos\ServiGest\resources\views/clientes/index.blade.php ENDPATH**/ ?>