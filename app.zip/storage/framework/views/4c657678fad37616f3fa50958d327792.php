<?php $__env->startSection('titulo', 'Órdenes de Trabajo'); ?>

<?php $__env->startSection('contenido'); ?>
<div>

    <!-- Filtros de Órdenes -->
    <div class="card" style="padding: 18px 24px; margin-bottom: 20px;">
        <form method="GET" action="<?php echo e(route('ordenes.index')); ?>" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 14px;">
            <div style="display: flex; align-items: center; gap: 10px; flex: 1; flex-wrap: wrap;">
                <div class="search-input-wrapper" style="min-width: 280px; flex: 1;">
                    <i class="fa-solid fa-magnifying-glass"></i>
                    <input type="text" 
                           name="buscar" 
                           value="<?php echo e($busqueda ?? ''); ?>" 
                           oninput="autoBuscar(this.form)"
                           placeholder="🔍 Código OT, Cédula / Doc, cliente, serie o falla..." 
                           class="input-control"
                           autofocus>
                </div>

                <select name="estado" onchange="this.form.submit()" class="select-control">
                    <option value="">Todos los Estados</option>
                    <option value="pendiente" <?php echo e(($estado == 'pendiente') ? 'selected' : ''); ?>>🟡 Pendiente</option>
                    <option value="en_proceso" <?php echo e(($estado == 'en_proceso') ? 'selected' : ''); ?>>🔵 En Proceso</option>
                    <option value="finalizado" <?php echo e(($estado == 'finalizado') ? 'selected' : ''); ?>>🟢 Finalizado</option>
                    <option value="entregado" <?php echo e(($estado == 'entregado') ? 'selected' : ''); ?>>⚪ Entregado</option>
                    <option value="cancelado" <?php echo e(($estado == 'cancelado') ? 'selected' : ''); ?>>🔴 Cancelado</option>
                </select>

                <select name="tipo_ubicacion" onchange="this.form.submit()" class="select-control">
                    <option value="">Todas las Ubicaciones</option>
                    <option value="ingresado_al_taller" <?php echo e(($tipoUbicacion == 'ingresado_al_taller') ? 'selected' : ''); ?>>🏢 En Taller</option>
                    <option value="servicio_en_domicilio" <?php echo e(($tipoUbicacion == 'servicio_en_domicilio') ? 'selected' : ''); ?>>🏠 Domicilio</option>
                </select>

                <?php if(!empty($busqueda) || !empty($estado) || !empty($tipoUbicacion)): ?>
                    <a href="<?php echo e(route('ordenes.index')); ?>" class="btn btn-outline btn-icon" title="Limpiar filtros">
                        <i class="fa-solid fa-xmark"></i>
                    </a>
                <?php endif; ?>
            </div>

            <a href="<?php echo e(route('ordenes.create')); ?>" class="btn btn-primary">
                <i class="fa-solid fa-plus"></i>
                <span>Nueva Orden</span>
            </a>
        </form>
    </div>

    <!-- Tabla de Órdenes -->
    <div class="table-card">
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Código / Fecha</th>
                        <th>Cliente Titular</th>
                        <th>Equipo</th>
                        <th>Modalidad</th>
                        <th>Técnico Asignado</th>
                        <th>Estado</th>
                        <th>Total ($)</th>
                        <th style="text-align: right;">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $ordenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(route('ordenes.show', $orden)); ?>" style="text-decoration: none; color: inherit; display: block;">
                                    <strong style="color: #0284c7; font-size: 14px;"><?php echo e($orden->codigo_orden); ?></strong>
                                    <span style="font-size: 11px; color: #64748b; display: block;">
                                        <?php echo e($orden->fecha_ingreso?->format('d/m/Y h:i A')); ?>

                                    </span>
                                </a>
                            </td>
                            <td>
                                <a href="<?php echo e(route('clientes.show', $orden->cliente)); ?>" style="text-decoration: none; color: #0f172a; font-weight: 700; font-size: 13.5px; display: block;">
                                    <?php echo e($orden->cliente?->nombre_completo); ?>

                                </a>
                                <span style="font-size: 11px; color: #64748b; font-family: monospace;">
                                    <?php echo e($orden->cliente?->identificacion ? 'Doc: ' . $orden->cliente?->identificacion : $orden->cliente?->telefono); ?>

                                </span>
                            </td>
                            <td>
                                <span style="font-weight: 700; color: #334155; font-size: 13px; display: block;">
                                    <?php echo e($orden->equipo?->marca); ?> <?php echo e($orden->equipo?->modelo); ?>

                                </span>
                                <span style="font-size: 11px; color: #94a3b8; font-family: monospace;">
                                    <?php echo e($orden->equipo?->numero_serie ? 'S/N: ' . $orden->equipo?->numero_serie : 'Sin serial'); ?>

                                </span>
                            </td>
                            <td>
                                <?php if($orden->tipo_ubicacion === 'servicio_en_domicilio'): ?>
                                    <span class="badge badge-purple" style="font-size: 10px;">
                                        <i class="fa-solid fa-house"></i> Domicilio
                                    </span>
                                <?php else: ?>
                                    <span class="badge" style="background: #e0f2fe; color: #0369a1; border-color: #bae6fd; font-size: 10px;">
                                        <i class="fa-solid fa-shop"></i> Taller
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span style="font-size: 12.5px; color: #334155; font-weight: 600;">
                                    <?php echo e($orden->tecnico?->nombre_completo ?? 'Sin asignar'); ?>

                                </span>
                            </td>
                            <td>
                                <?php if($orden->estado === 'finalizado'): ?>
                                    <span class="badge badge-active"><i class="fa-solid fa-circle-check"></i> Finalizado</span>
                                <?php elseif($orden->estado === 'en_proceso'): ?>
                                    <span class="badge badge-process"><i class="fa-solid fa-screwdriver-wrench"></i> En Proceso</span>
                                <?php elseif($orden->estado === 'entregado'): ?>
                                    <span class="badge badge-slate"><i class="fa-solid fa-box-open"></i> Entregado</span>
                                <?php elseif($orden->estado === 'cancelado'): ?>
                                    <span class="badge badge-danger"><i class="fa-solid fa-ban"></i> Cancelado</span>
                                <?php else: ?>
                                    <span class="badge badge-pending"><i class="fa-solid fa-clock"></i> Pendiente</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong style="font-size: 14px; color: #0f172a;">$<?php echo e(number_format($orden->costo_total, 0, ',', '.')); ?></strong>
                            </td>
                            <td style="text-align: right;">
                                <div style="display: inline-flex; gap: 6px;">
                                    <!-- Botón Enviar WhatsApp con Reporte Público -->
                                    <a href="<?php echo e($orden->enlace_whatsapp_reporte); ?>" target="_blank" class="btn btn-emerald btn-icon" title="Enviar reporte por WhatsApp" style="width: 30px; height: 30px; font-size: 13px;">
                                        <i class="fa-brands fa-whatsapp"></i>
                                    </a>

                                    <a href="<?php echo e(route('ordenes.show', $orden)); ?>" class="btn btn-outline btn-icon" title="Ver Detalles">
                                        <i class="fa-solid fa-eye" style="color: #0284c7;"></i>
                                    </a>

                                    <a href="<?php echo e(route('ordenes.edit', $orden)); ?>" class="btn btn-outline btn-icon" title="Editar / Gestionar">
                                        <i class="fa-solid fa-pen-to-square" style="color: #d97706;"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" style="text-align: center; padding: 40px; color: #94a3b8;">
                                <i class="fa-solid fa-clipboard-question" style="font-size: 32px; display: block; margin-bottom: 8px;"></i>
                                No se encontraron órdenes de trabajo registradas.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($ordenes->hasPages()): ?>
            <div style="padding: 16px 20px; border-top: 1px solid var(--border);">
                <?php echo e($ordenes->links()); ?>

            </div>
        <?php endif; ?>
    </div>

</div>

<script>
    var debounceTimer;
    function autoBuscar(form) {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(function() {
            form.submit();
        }, 400);
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Proyectos\ServiGest\resources\views/ordenes/index.blade.php ENDPATH**/ ?>