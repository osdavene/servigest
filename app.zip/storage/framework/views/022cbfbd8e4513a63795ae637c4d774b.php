<?php $__env->startSection('titulo', 'Gestión de Talleres SaaS'); ?>

<?php $__env->startSection('contenido'); ?>
<div>

    <div class="filter-bar">
        <form method="GET" action="<?php echo e(route('superadmin.talleres.index')); ?>" class="search-group" style="flex: 1; max-width: 540px;">
            <div class="search-input-wrapper" style="width: 100%;">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" 
                       name="buscar" 
                       value="<?php echo e($busqueda ?? ''); ?>" 
                       oninput="autoBuscar(this.form)"
                       placeholder="🔍 Nombre de taller, NIT, correo, teléfono, ciudad..." 
                       class="input-control"
                       autofocus>
            </div>
            <?php if(!empty($busqueda)): ?>
                <a href="<?php echo e(route('superadmin.talleres.index')); ?>" class="btn btn-outline btn-icon" title="Limpiar búsqueda">
                    <i class="fa-solid fa-xmark"></i>
                </a>
            <?php endif; ?>
        </form>

        <a href="<?php echo e(route('superadmin.talleres.create')); ?>" class="btn btn-amber">
            <i class="fa-solid fa-plus"></i>
            <span>Nuevo Taller</span>
        </a>
    </div>

    <!-- Tabla de Talleres con Diseño de Alta Fidelidad -->
    <div class="table-card">
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Taller / Razón Social</th>
                        <th>Contacto Principal</th>
                        <th>Estado Suscripción</th>
                        <th>Vencimiento</th>
                        <th style="text-align: center;">Usuarios</th>
                        <th style="text-align: center;">Clientes</th>
                        <th style="text-align: center;">Órdenes</th>
                        <th style="text-align: right;">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $talleres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <strong style="color: #0f172a; font-size: 14px; display: block;"><?php echo e($taller->nombre_comercial); ?></strong>
                                <span style="font-size: 11px; color: #94a3b8;"><?php echo e($taller->identificacion_fiscal ? 'NIT: ' . $taller->identificacion_fiscal : 'Sin NIT'); ?> • <?php echo e($taller->ciudad); ?></span>
                            </td>
                            <td>
                                <div style="font-weight: 700; color: #334155;"><?php echo e($taller->telefono); ?></div>
                                <span style="font-size: 11px; color: #94a3b8;"><?php echo e($taller->email); ?></span>
                            </td>
                            <td>
                                <?php if($taller->estado_suscripcion === 'activo'): ?>
                                    <span class="badge badge-active">
                                        <i class="fa-solid fa-circle-check"></i> Activo
                                    </span>
                                <?php elseif($taller->estado_suscripcion === 'periodo_prueba'): ?>
                                    <span class="badge badge-pending">
                                        <i class="fa-solid fa-clock"></i> Prueba
                                    </span>
                                <?php else: ?>
                                    <span class="badge badge-danger">
                                        <i class="fa-solid fa-circle-xmark"></i> Suspendido
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span style="font-size: 13px; font-weight: 700; color: #0f172a; display: block;">
                                    <?php echo e($taller->fecha_fin_suscripcion?->format('d/m/Y')); ?>

                                </span>
                                <?php if($taller->dias_restantes_licencia <= 7): ?>
                                    <span class="badge badge-danger" style="font-size: 9px;">¡<?php echo e($taller->dias_restantes_licencia); ?> días!</span>
                                <?php else: ?>
                                    <span style="font-size: 11px; color: #64748b;"><?php echo e($taller->dias_restantes_licencia); ?> días rest.</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: center;">
                                <span class="badge badge-slate"><?php echo e($taller->usuarios_count); ?></span>
                            </td>
                            <td style="text-align: center;">
                                <span class="badge badge-slate"><?php echo e($taller->clientes_count); ?></span>
                            </td>
                            <td style="text-align: center;">
                                <span class="badge badge-slate"><?php echo e($taller->ordenes_trabajo_count); ?></span>
                            </td>
                            <td style="text-align: right;">
                                <div style="display: inline-flex; gap: 6px;">
                                    <a href="<?php echo e(route('superadmin.talleres.show', $taller)); ?>" class="btn btn-outline btn-icon" title="Ver Detalle">
                                        <i class="fa-solid fa-eye" style="color: #0284c7;"></i>
                                    </a>
                                    <a href="<?php echo e(route('superadmin.talleres.edit', $taller)); ?>" class="btn btn-outline btn-icon" title="Editar">
                                        <i class="fa-solid fa-pen-to-square" style="color: #d97706;"></i>
                                    </a>
                                    <form action="<?php echo e(route('superadmin.talleres.toggle-estado', $taller)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-outline btn-icon" title="<?php echo e($taller->estado_suscripcion === 'activo' ? 'Suspender' : 'Activar'); ?>">
                                            <i class="fa-solid <?php echo e($taller->estado_suscripcion === 'activo' ? 'fa-ban text-rose-600' : 'fa-check text-emerald-600'); ?>"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" style="text-align: center; padding: 40px; color: #94a3b8;">
                                <i class="fa-solid fa-shop-slash" style="font-size: 32px; display: block; margin-bottom: 8px;"></i>
                                No se encontraron talleres suscritos.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($talleres->hasPages()): ?>
            <div style="padding: 16px 20px; border-top: 1px solid var(--border);">
                <?php echo e($talleres->links()); ?>

            </div>
        <?php endif; ?>
    </div>

</div>

<script>
    var debounceTimer;
    function autoBuscar(form) {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(function() {
            form.submit();
        }, 400);
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Proyectos\ServiGest\resources\views/superadmin/talleres/index.blade.php ENDPATH**/ ?>